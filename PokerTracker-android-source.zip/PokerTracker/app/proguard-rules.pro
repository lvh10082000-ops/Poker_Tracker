-keepclassmembers class com.edward.pokertracker.MainActivity$Bridge {
    public *;
}
-keepattributes JavascriptInterface
