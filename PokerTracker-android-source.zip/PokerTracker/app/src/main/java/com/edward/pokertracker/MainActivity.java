package com.edward.pokertracker;

import android.app.Activity;
import android.content.Intent;
import android.net.Uri;
import android.os.Bundle;
import android.view.KeyEvent;
import android.view.ViewGroup;
import android.webkit.JavascriptInterface;
import android.webkit.ValueCallback;
import android.webkit.WebChromeClient;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Toast;

import java.io.OutputStream;
import java.nio.charset.StandardCharsets;

/**
 * Poker Tracker — vỏ native cho giao diện HTML nằm trong assets/index.html.
 * Toàn bộ dữ liệu lưu trong localStorage của WebView (chỉ nằm trong máy).
 */
public class MainActivity extends Activity {

    private static final int REQ_PICK_FILE = 1001;   // chọn file backup để nhập
    private static final int REQ_SAVE_FILE = 1002;   // chọn nơi lưu file xuất ra

    private WebView web;
    private ValueCallback<Uri[]> pickCallback;
    private String pendingContent;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        web = new WebView(this);
        web.setLayoutParams(new ViewGroup.LayoutParams(
                ViewGroup.LayoutParams.MATCH_PARENT, ViewGroup.LayoutParams.MATCH_PARENT));
        web.setBackgroundColor(0xFF111110);
        setContentView(web);

        WebSettings s = web.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);          // localStorage — nơi chứa dữ liệu phiên
        s.setDatabaseEnabled(true);
        s.setAllowFileAccess(true);
        s.setLoadWithOverviewMode(false);
        s.setUseWideViewPort(true);
        s.setSupportZoom(false);
        s.setBuiltInZoomControls(false);
        s.setTextZoom(100);                    // không đổi theo cỡ chữ hệ thống

        web.setWebViewClient(new WebViewClient());
        web.setWebChromeClient(new WebChromeClient() {
            @Override
            public boolean onShowFileChooser(WebView v, ValueCallback<Uri[]> cb,
                                             FileChooserParams params) {
                if (pickCallback != null) pickCallback.onReceiveValue(null);
                pickCallback = cb;
                try {
                    startActivityForResult(params.createIntent(), REQ_PICK_FILE);
                    return true;
                } catch (Exception e) {
                    pickCallback = null;
                    return false;
                }
            }
        });

        web.addJavascriptInterface(new Bridge(), "AndroidBridge");
        web.loadUrl("file:///android_asset/index.html");
    }

    /** Cầu nối cho nút "Xuất backup" / "Xuất CSV" trong giao diện web.
     *  Phải để public thì WebView mới gọi được qua reflection. */
    public class Bridge {
        @JavascriptInterface
        public void saveFile(final String name, final String content, final String mime) {
            pendingContent = content;
            runOnUiThread(new Runnable() {
                @Override public void run() {
                    Intent i = new Intent(Intent.ACTION_CREATE_DOCUMENT);
                    i.addCategory(Intent.CATEGORY_OPENABLE);
                    i.setType(mime == null ? "application/octet-stream" : mime);
                    i.putExtra(Intent.EXTRA_TITLE, name);
                    try {
                        startActivityForResult(i, REQ_SAVE_FILE);
                    } catch (Exception e) {
                        toast("Không mở được trình quản lý file");
                    }
                }
            });
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent data) {
        super.onActivityResult(req, res, data);

        if (req == REQ_PICK_FILE) {
            if (pickCallback == null) return;
            Uri[] out = null;
            if (res == RESULT_OK && data != null && data.getData() != null) {
                out = new Uri[]{ data.getData() };
            }
            pickCallback.onReceiveValue(out);
            pickCallback = null;
            return;
        }

        if (req == REQ_SAVE_FILE) {
            if (res != RESULT_OK || data == null || data.getData() == null || pendingContent == null) {
                pendingContent = null;
                return;
            }
            OutputStream os = null;
            try {
                os = getContentResolver().openOutputStream(data.getData());
                if (os != null) {
                    os.write(pendingContent.getBytes(StandardCharsets.UTF_8));
                    os.flush();
                    toast("Đã lưu file");
                }
            } catch (Exception e) {
                toast("Lưu file thất bại");
            } finally {
                try { if (os != null) os.close(); } catch (Exception ignored) {}
                pendingContent = null;
            }
        }
    }

    private void toast(String m) {
        Toast.makeText(this, m, Toast.LENGTH_SHORT).show();
    }

    /** Nút Back: nếu đang ở tab khác thì quay về tab Nhập, bấm lần nữa mới thoát. */
    @Override
    public boolean onKeyDown(int keyCode, KeyEvent event) {
        if (keyCode == KeyEvent.KEYCODE_BACK) {
            web.evaluateJavascript(
                "(function(){var b=document.querySelector('#nav button.on');" +
                "if(b&&b.dataset.t!=='add'){go('add');return 'handled';}return 'exit';})()",
                new ValueCallback<String>() {
                    @Override public void onReceiveValue(String value) {
                        if (value != null && value.contains("exit")) moveTaskToBack(true);
                    }
                });
            return true;
        }
        return super.onKeyDown(keyCode, event);
    }
}
