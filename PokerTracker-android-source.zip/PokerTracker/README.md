# Poker Tracker — NLH 8max Auto Straddle 1/2/4

App Android theo dõi profit hằng ngày. Toàn bộ dữ liệu nằm trong máy, không gửi đi đâu
(chỉ gọi mạng để lấy tỷ giá USD → ¥ / ₫).

---

## 1. Cách build ra file APK

**Cần:** [Android Studio](https://developer.android.com/studio) (bản nào cũng được, từ Hedgehog trở lên).

1. Giải nén thư mục `PokerTracker`.
2. Mở Android Studio → **Open** → chọn thư mục `PokerTracker` (thư mục có file `settings.gradle`).
3. Đợi Gradle sync xong lần đầu (5–10 phút, cần mạng để tải Android Gradle Plugin).
4. Menu **Build → Build Bundle(s) / APK(s) → Build APK(s)**.
5. Bấm **locate** trong thông báo hiện ra. File nằm ở:

   ```
   app/build/outputs/apk/debug/app-debug.apk
   ```

6. Copy file `app-debug.apk` sang điện thoại Samsung, mở file đó, chọn **Cài đặt**.
   Nếu máy chặn: Cài đặt → Ứng dụng → truy cập đặc biệt → **Cài ứng dụng không rõ nguồn gốc**
   → bật cho "Quản lý file" / trình duyệt bạn dùng để mở file.

### Cách nhanh hơn — build bằng dòng lệnh

```bash
cd PokerTracker
./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
```

APK ra ở `app/build/outputs/apk/debug/app-debug.apk`.

### Nếu muốn bản release (không cần cắm máy tính để cập nhật)

```bash
./gradlew assembleRelease
```
Bản release cần chữ ký. Trong Android Studio: **Build → Generate Signed App Bundle / APK → APK**,
tạo keystore mới, giữ lại file keystore đó để lần sau cập nhật app.

---

## 2. Dùng luôn không cần build

File `app/src/main/assets/index.html` chính là toàn bộ app. Copy nó vào điện thoại,
mở bằng Chrome → menu ⋮ → **Thêm vào Màn hình chính**. Chạy y hệt, offline được,
dữ liệu lưu trong Chrome. Cách này không cần máy tính.

> Lưu ý: nếu dùng cách này thì **đừng xoá dữ liệu duyệt web của Chrome**, vì dữ liệu phiên
> lưu trong localStorage của Chrome. Nên bấm "Xuất file backup" định kỳ.

---

## 3. Nhập liệu

| Ô | Ý nghĩa |
|---|---|
| Ngày | Ngày chơi |
| Hand đầu ngày | Số hand hiển thị trên app poker lúc bắt đầu |
| Hand cuối ngày | Số hand lúc kết thúc |
| Tiền đầu ngày | Số dư lúc bắt đầu — **đơn vị $ (USD)** |
| Tiền cuối ngày | Số dư lúc kết thúc — **đơn vị $ (USD)** |

App tự điền sẵn hand đầu / tiền đầu bằng số cuối của phiên gần nhất.

## 4. Công thức

```
Hand      = hand cuối − hand đầu
Profit($) = tiền cuối − tiền đầu
Profit(¥) = Profit($) × tỷ giá lúc nhập phiên
Số bb     = Profit(¥) ÷ 2          (1bb = 2¥, chỉnh được trong Cài đặt)
bb/100    = Số bb ÷ Hand × 100
```

**bb/100 tổng** tính theo trọng số hand (`tổng bb ÷ tổng hand × 100`), không phải trung bình
cộng của từng ngày — ngày chơi 1.500 hand có ảnh hưởng lớn hơn ngày chơi 300 hand.

Mỗi phiên **lưu lại tỷ giá USD→¥ tại thời điểm nhập**, nên winrate quá khứ không bị
thay đổi khi tỷ giá biến động.

## 5. Tỷ giá

Tự động lấy khi mở app (nếu tỷ giá đã cũ hơn 12 tiếng) từ `open.er-api.com`,
có 2 nguồn dự phòng. Không có mạng thì dùng tỷ giá đã lưu lần trước.
Sửa tay được trong tab **Cài đặt**.

## 6. Backup

Tab **Cài đặt**:
- **Xuất file backup** → file `.json`, giữ được toàn bộ phiên + cài đặt.
- **Nhập backup** → khôi phục lại (ghi đè dữ liệu hiện tại).
- **Xuất CSV** → mở bằng Excel / Google Sheets.

Nên xuất backup mỗi tháng một lần và lưu lên Google Drive.

---

## Cấu trúc project

```
PokerTracker/
├── settings.gradle, build.gradle, gradle.properties
├── gradlew, gradlew.bat, gradle/wrapper/     ← Gradle wrapper
└── app/
    ├── build.gradle                          ← cấu hình app, không phụ thuộc thư viện ngoài
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html                 ← TOÀN BỘ giao diện + logic nằm ở đây
        ├── java/com/edward/pokertracker/MainActivity.java
        └── res/                              ← icon, theme, màu
```

Muốn sửa giao diện hay công thức: chỉ cần sửa `app/src/main/assets/index.html` rồi build lại.
