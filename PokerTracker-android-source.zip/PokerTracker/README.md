# Poker Tracker — NLH 8max Auto Straddle 1/2/4¥

App theo dõi profit hằng ngày. Dữ liệu nằm hoàn toàn trong máy, không gửi đi đâu
(chỉ gọi mạng để lấy tỷ giá USD → ¥ / ₫).

## Có gì mới ở bản 2.0

- **Rakeback**, tách hẳn khỏi winrate.
- **Vốn hiện tại** = số dư cuối phiên gần nhất **+ rakeback nhận sau ngày đó**, kèm phép cộng hiện rõ trên thẻ.
- **Khoảng tin cậy 95%** của bb/100 (σ = 190 theo đơn vị app) — cả con số lẫn dải mờ trên biểu đồ.
- Quy vốn ra **số buy-in**, chỉnh được giá trị 1 buy-in trong Cài đặt.
- Tab Tháng có thêm cột Rakeback / Tổng và biểu đồ rakeback theo tháng.
- Lịch sử tách hai mục: **Phiên chơi** và **Rakeback**.

---

## 1. Build ra file APK

**Cần:** [Android Studio](https://developer.android.com/studio), ~15 GB trống, JDK 21 (Studio có sẵn).

1. Giải nén, mở Android Studio → **File → Open** → chọn thư mục `PokerTracker`
   (thư mục chứa `settings.gradle`).
2. Nếu hỏi Gradle JDK → chọn **21** / `jbr-21`.
3. Đợi Gradle sync xong.
4. **Build → Build Bundle(s)/APK(s) → Build APK(s)**.
5. File nằm ở `app/build/outputs/apk/debug/app-debug.apk`.

Hoặc dòng lệnh:

```bash
cd PokerTracker
./gradlew assembleDebug          # Windows: gradlew.bat assembleDebug
```

### Không có máy tính — để GitHub build hộ

Upload file zip này lên một repo GitHub, thêm file `.github/workflows/build.yml`:

```yaml
name: Build APK
on:
  push:
  workflow_dispatch:
permissions:
  contents: write
jobs:
  build:
    runs-on: ubuntu-latest
    steps:
      - uses: actions/checkout@v4
      - uses: actions/setup-java@v4
        with:
          distribution: temurin
          java-version: '17'
      - name: Giai nen project
        run: unzip -q "$(ls *.zip | head -1)"
      - name: Build APK
        run: |
          cd PokerTracker
          chmod +x gradlew
          ./gradlew assembleDebug --no-daemon
      - name: Doi ten file
        run: cp PokerTracker/app/build/outputs/apk/debug/app-debug.apk poker-tracker.apk
      - uses: actions/upload-artifact@v4
        with:
          name: poker-tracker-apk
          path: poker-tracker.apk
      - name: Tao Release
        env:
          GH_TOKEN: ${{ github.token }}
        run: |
          gh release create "v${{ github.run_number }}" poker-tracker.apk \
            --title "Poker Tracker v${{ github.run_number }}" \
            --notes "Tai poker-tracker.apk roi cai tren dien thoai."
```

Vào tab **Actions** đợi build xong, rồi tải APK ở mục **Releases**.

---

## 2. Dùng luôn không cần build

File `app/src/main/assets/index.html` chính là toàn bộ app. Copy vào điện thoại,
mở bằng **Samsung Internet** → ☰ → **Thêm trang vào** → **Màn hình chính**.

> Chrome cố tình ẩn "Thêm vào Màn hình chính" với file trong máy (`file://`),
> nên dùng Samsung Internet hoặc lưu dấu trang.
> Cách này dữ liệu nằm trong trình duyệt — **đừng xoá dữ liệu duyệt web**, và nhớ xuất backup định kỳ.

---

## 3. Nhập liệu

| Ô | Ý nghĩa |
|---|---|
| Hand đầu / cuối ngày | Số hand hiển thị trên app poker lúc bắt đầu và kết thúc |
| Tiền đầu / cuối ngày | Số dư lúc bắt đầu và kết thúc — **đơn vị $ (USD)** |
| Rakeback | Ngày nhận + số tiền ($). Không ảnh hưởng winrate |

App tự điền sẵn hand đầu / tiền đầu bằng số cuối của phiên gần nhất.

## 4. Công thức

```
Hand      = hand cuối − hand đầu
Profit($) = tiền cuối − tiền đầu
Số bb     = Profit($) × tỷ giá(¥/$) ÷ 2
bb/100    = Số bb ÷ Hand × 100
KTC 95%   = ±1,96 × σ ÷ √(Hand ÷ 100)      với σ = 190

Vốn hiện tại = số dư cuối phiên gần nhất + rakeback có ngày SAU phiên đó
```

**Vì sao rakeback không lọt vào winrate:** profit mỗi ngày chỉ là chênh lệch
*trong cùng một ngày*, nên tiền rakeback rơi vào tài khoản giữa hai phiên không
bao giờ được tính là tiền thắng trên bàn.

**Vì sao bankroll chỉ cộng rakeback mới:** những khoản rakeback cũ đã nằm sẵn
trong số dư cuối phiên gần nhất rồi — cộng lại là đếm hai lần.

**bb/100 tổng** tính theo trọng số hand (`tổng bb ÷ tổng hand × 100`), không phải
trung bình cộng của từng ngày.

## 5. Backup

Tab **Cài đặt**: xuất/nhập file `.json` (gồm cả rakeback), hoặc xuất CSV cho Excel.
Nên xuất backup mỗi tháng và lưu lên Google Drive.

---

## Cấu trúc project

```
PokerTracker/
├── settings.gradle, build.gradle, gradle.properties
├── gradlew, gradlew.bat, gradle/wrapper/
└── app/
    ├── build.gradle                          ← không phụ thuộc thư viện ngoài
    └── src/main/
        ├── AndroidManifest.xml
        ├── assets/index.html                 ← TOÀN BỘ giao diện + logic
        ├── java/com/edward/pokertracker/MainActivity.java
        └── res/
```

Sửa giao diện hay công thức: chỉ cần sửa `app/src/main/assets/index.html` rồi build lại.
